package Dat.populator;

import Dat.Category;
import Dat.dao.ItemDAO;
import Dat.dao.StudentDAO;
import Dat.entity.Item;
import Dat.entity.Student;

import java.time.LocalDate;

public class Populator {
    public static void main(String[] args) {
        StudentDAO studentDAO = new StudentDAO();
        ItemDAO itemDAO = new ItemDAO();

        // Student 1
        Student student1 = new Student("Jon Doe", "john.doe@example.com", LocalDate.of(2023, 9, 1), 123456789);
        Item item1 = new Item("Hammer", 25.50, Category.TOOL, LocalDate.of(2023, 7, 5), "A basic hammer.");
        studentDAO.create(student1);
        student1.borrowItem(item1);// Borrow item1
        itemDAO.create(item1);




        // Student 2
        Student student2 = new Student("Jane Smith", "jane.smith@example.com", LocalDate.of(2023, 8, 15), 987654321);
        Item item2 = new Item("Screwdriver", 10.00, Category.TOOL, LocalDate.of(2023, 6, 10), "A basic screwdriver.");
        studentDAO.create(student2);
        student2.borrowItem(item2);  // Borrow item2
        itemDAO.create(item2);


        // Student 3
        Student student3 = new Student("Alice Johnson", "alice.johnson@example.com", LocalDate.of(2023, 7, 1), 123123123);
        Item item3 = new Item("Wrench", 15.75, Category.TOOL, LocalDate.of(2023, 5, 15), "A basic wrench.");
        studentDAO.create(student3);
        itemDAO.create(item3);


        // Student 4
        Student student4 = new Student("Bob Brown", "bob.brown@example.com", LocalDate.of(2023, 6, 20), 321321321);
        Item item4 = new Item("Pliers", 12.25, Category.TOOL, LocalDate.of(2023, 4, 20), "A basic pliers.");
        studentDAO.create(student4);
        itemDAO.create(item4);


        // Student 5
        Student student5 = new Student("Charlie Green", "charlie.green@example.com", LocalDate.of(2023, 5, 10), 555555555);
        Item item5 = new Item("Notebook", 5.00, Category.VIDEO, LocalDate.of(2023, 3, 25), "A movie that can make anyone cry!");
        studentDAO.create(student5);
        student5.borrowItem(item5);  // Borrow item5
        itemDAO.create(item5);

        // Student 6
        Student student6 = new Student("David White", "david.white@example.com", LocalDate.of(2023, 4, 25), 777777777);
        Item item6 = new Item("Exorcist", 1.50, Category.VIDEO, LocalDate.of(2023, 2, 10), "You love getting the creeps? Watch this!");
        studentDAO.create(student6);
        itemDAO.create(item6);


        // Student 7
        Student student7 = new Student("Emma Black", "emma.black@example.com", LocalDate.of(2023, 3, 15), 888888888);
        Item item7 = new Item("Christina Aguilera - Bionic Album", 2.50, Category.SOUND, LocalDate.of(2023, 1, 30), "BEST ARTIST EVER!");
        studentDAO.create(student7);
        student7.borrowItem(item7);  // Borrow item7
        itemDAO.create(item7);


        // Student 8
        Student student8 = new Student("Frank Yellow", "frank.yellow@example.com", LocalDate.of(2023, 2, 5), 444444444);
        Item item8 = new Item("Adele - 21 Album", 3.50, Category.SOUND, LocalDate.of(2023, 1, 15), "The British queen is back!");
        studentDAO.create(student8);
        itemDAO.create(item8);


        // Student 9
        Student student9 = new Student("Grace Blue", "grace.blue@example.com", LocalDate.of(2023, 1, 30), 999999999);
        Item item9 = new Item("Oculus Rift VR", 399.99, Category.VR, LocalDate.of(2022, 12, 25), "An immersive VR experience.");
        studentDAO.create(student9);
        itemDAO.create(item9);


        // Student 10
        Student student10 = new Student("Hannah Pink", "hannah.pink@example.com", LocalDate.of(2022, 12, 10), 101010101);
        Item item10 = new Item("HP Printer", 120.00, Category.PRINT, LocalDate.of(2022, 11, 10), "An all-in-one printer.");
        studentDAO.create(student10);
        student10.borrowItem(item10);  // Borrow item10
        itemDAO.create(item10);


        // Student 11
        Student student11 = new Student("Isaac Violet", "isaac.violet@example.com", LocalDate.of(2022, 11, 25), 202020202);
        Item item11 = new Item("Canon Printer", 150.00, Category.PRINT, LocalDate.of(2022, 10, 15), "A high-quality printer.");
        studentDAO.create(student11);
        itemDAO.create(item11);


        // Student 12
        Student student12 = new Student("Jack Red", "jack.red@example.com", LocalDate.of(2022, 10, 12), 303030303);
        Item item12 = new Item("Laser Pointer", 8.00, Category.TOOL, LocalDate.of(2022, 9, 5), "A red laser pointer.");
        studentDAO.create(student12);
        itemDAO.create(item12);


        // Student 13
        Student student13 = new Student("Karen Orange", "karen.orange@example.com", LocalDate.of(2022, 9, 8), 404040404);
        Item item13 = new Item("Blender", 60.00, Category.VIDEO, LocalDate.of(2022, 8, 10), "A high-speed blender.");
        studentDAO.create(student13);
        itemDAO.create(item13);


        // Student 14
        Student student14 = new Student("Liam Grey", "liam.grey@example.com", LocalDate.of(2022, 8, 22), 505050505);
        Item item14 = new Item("Yoga Mat", 20.00, Category.VR, LocalDate.of(2022, 7, 30), "A comfortable yoga mat.");
        studentDAO.create(student14);
        itemDAO.create(item14);


        // Student 15
        Student student15 = new Student("Mia Brown", "mia.brown@example.com", LocalDate.of(2022, 7, 18), 606060606);
        Item item15 = new Item("Fitness Tracker", 50.00, Category.VR, LocalDate.of(2022, 6, 5), "Track your workouts.");
        studentDAO.create(student15);
        student15.borrowItem(item15);  // Borrow item15
        itemDAO.create(item15);


        System.out.println("Database populated with students and items.");
    }
}
