package Dat.controllers;

import Dat.Category;
import Dat.dao.ItemDAO;
import Dat.dto.ItemDTO;
import Dat.entity.Item;
import Dat.entity.Student;
import io.javalin.http.Context;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

public class ItemController {

    static ItemDAO itemDAO = new ItemDAO();




    public static void getAllItems(Context ctx) {
        List<ItemDTO> itemDTO = itemDAO.getAll().stream()
                .map(item -> item.toDTO())
                .collect(Collectors.toList());
        ctx.json(itemDTO);
    }

    public static void getItemById(Context context) {
        int id = Integer.parseInt(context.pathParam("id"));
        Item item = itemDAO.getById(id);
        if (item != null) {
            context.json(item.toDTO());
        } else {
            context.status(404).result("Item not found");
        }
    }

    public static void addItem(Context ctx) {
        // Receive the ItemDTO from the request body
        ItemDTO itemDTO = ctx.bodyAsClass(ItemDTO.class);

        // Map the ItemDTO to an Item entity
        Item item = new Item(
                itemDTO.name(),
                itemDTO.price(),
                Category.valueOf(itemDTO.category().toString()),
                LocalDate.now(),
                "No description available"
        );

        // Save the Item entity using ItemDAO
        itemDAO.create(item);

        // Respond with a status and the ItemDTO (for consistency with your API)
        ctx.status(201).json(item.toDTO());
    }


    public static void deleteItem(Context context) {
    }

    public static void getItemsByCategory(Context context) {
    }

    public static void updateItem(Context context) {
    }

    public static void populate(Context context) {
        itemDAO.populateDatabase();
        //status 200 means the request was successful
        context.status(200).result("Database populated");
    }

    public static void assignItemToStudent(Context context) {
        // Retrieve path parameters: itemId and studentId
        int itemId = Integer.parseInt(context.pathParam("itemId"));
        int studentId = Integer.parseInt(context.pathParam("studentId"));

        // Try to assign the item to the student
        boolean success = itemDAO.assignItemToStudent(itemId, studentId);

        if (success) {
            // Send success status and message if item is assigned
            context.status(200).result("Item assigned to student");
        } else {
            // Send error status and message if item or student is not found
            context.status(404).result("Item or student not found");
        }
    }
}
