package Dat.dao;

import Dat.config.HibernateConfig;
import Dat.entity.Student;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

import java.util.List;

public class StudentDAO implements IDAO<Student>{

    EntityManagerFactory entityManagerFactory = HibernateConfig.getEntityManagerFactoryConfig();

    @Override
    public void create(Student student) {
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        em.persist(student);
        em.getTransaction().commit();
        em.close();
    }

    @Override
    public Student getById(int id) {
        EntityManager em = entityManagerFactory.createEntityManager();
        return em.find(Student.class, id);
    }

    @Override
    public List<Student> getAll() {
        EntityManager em = entityManagerFactory.createEntityManager();
        return em.createQuery("SELECT s FROM Student s", Student.class).getResultList();
    }

    @Override
    public void update(Student student) {
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        em.merge(student);
        em.getTransaction().commit();
        em.close();
    }

    @Override
    public void delete(int id) {
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        Student student = em.find(Student.class, id);
        em.remove(student);
        em.getTransaction().commit();
        em.close();
    }

    //TODO - MAKE A METHOD THAT CAN RETRIEVE ALL THE ITEMS FROM A STUDENT
}
