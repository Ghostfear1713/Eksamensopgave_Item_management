package Dat.dao;

import Dat.Category;
import Dat.config.HibernateConfig;
import Dat.dto.ItemDTO;
import Dat.entity.Item;
import Dat.entity.Student;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

public class ItemDAO implements IDAO<Item> {
    EntityManagerFactory entityManagerFactory = HibernateConfig.getEntityManagerFactoryConfig();

    public void create(Item item) {
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        em.persist(item);
        em.getTransaction().commit();
        em.close();
    }

    public Item getById(int id) {
        EntityManager em = entityManagerFactory.createEntityManager();
        return em.find(Item.class, id);
    }

    public List<Item> getAll() {
        EntityManager em = entityManagerFactory.createEntityManager();
        return em.createQuery("SELECT i FROM Item i", Item.class).getResultList();
    }

    public void update(Item item) {
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        em.merge(item);
        em.getTransaction().commit();
        em.close();
    }

    public void delete(int id) {
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        Item item = em.find(Item.class, id);
        em.remove(item);
        em.getTransaction().commit();
        em.close();
    }


    public void populateDatabase() {
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        // Item 1 - TOOL
        Item item1 = new Item("Circular Saw", 75.00, Category.TOOL, LocalDate.of(2023, 8, 15), "A powerful circular saw for wood cutting.");
        em.persist(item1);

        // Item 2 - TOOL
        Item item2 = new Item("Drill", 45.50, Category.TOOL, LocalDate.of(2023, 7, 12), "A versatile drill with multiple speed settings.");
        em.persist(item2);

        // Item 3 - TOOL
        Item item3 = new Item("Level", 10.00, Category.TOOL, LocalDate.of(2023, 6, 5), "A 24-inch spirit level for precise measurements.");
        em.persist(item3);

        // Item 4 - SOUND
        Item item4 = new Item("Bohemian Rhapsody Album", 18.99, Category.SOUND, LocalDate.of(2023, 5, 25), "A timeless classic by Queen.");
        em.persist(item4);

        // Item 5 - SOUND
        Item item5 = new Item("The Beatles: Abbey Road", 22.50, Category.SOUND, LocalDate.of(2023, 4, 18), "One of the most influential albums in history.");
        em.persist(item5);

        // Item 6 - VR
        Item item6 = new Item("VR Headset", 199.99, Category.VR, LocalDate.of(2023, 3, 10), "An immersive virtual reality headset.");
        em.persist(item6);

        // Item 7 - VR
        Item item7 = new Item("VR Gloves", 150.00, Category.VR, LocalDate.of(2023, 2, 5), "Advanced gloves for full immersion in VR.");
        em.persist(item7);

        // Item 8 - PRINT
        Item item8 = new Item("Laser Printer", 120.00, Category.PRINT, LocalDate.of(2023, 1, 30), "High-speed laser printer with wireless functionality.");
        em.persist(item8);

        // Item 9 - PRINT
        Item item9 = new Item("Inkjet Printer", 80.00, Category.PRINT, LocalDate.of(2022, 12, 10), "Affordable inkjet printer with high-quality prints.");
        em.persist(item9);

        // Item 10 - VIDEO
        Item item10 = new Item("Action Camera", 150.00, Category.VIDEO, LocalDate.of(2022, 11, 5), "Compact action camera for all your adventure needs.");
        em.persist(item10);

        em.getTransaction().commit();
        em.close();
    }

    public boolean assignItemToStudent(int itemId, int studentId) {
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();

        Item item = em.find(Item.class, itemId);
        Student student = em.find(Student.class, studentId);

        if (item != null && student != null) {
            Set<Item> items = student.getItemList();
            items.add(item);
            student.setItemList(items);
            em.merge(student);
            em.getTransaction().commit();
            em.close();
            return true;
        } else {
            em.getTransaction().rollback();
            em.close();
            return false;
        }
    }
}








