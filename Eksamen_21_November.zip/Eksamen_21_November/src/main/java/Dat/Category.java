package Dat;

public enum Category {
    VIDEO,
    VR,
    SOUND,
    PRINT,
    TOOL
}
