package Dat;

import Dat.controllers.ItemController;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import io.javalin.Javalin;
import io.javalin.plugin.json.JavalinJackson;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        ObjectMapper objectMapper = JavalinJackson.getObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());


        Javalin app = Javalin.create().start(5000);


        app.get("/items", ItemController::getAllItems);
        app.get("/items/:id", ItemController::getItemById);
        app.get("/items/category/:category", ItemController::getItemsByCategory);


        app.post("/items", ItemController::addItem);
        app.post("/items/populate", ItemController::populate);


        app.put("/items", ItemController::updateItem);
        app.put("/items/assign/:itemId/:studentId", ItemController::assignItemToStudent);


        app.delete("/items/:id", ItemController::deleteItem);







    }
}