# Eksamensopgave 21.11.2024

## Fetch all items
GET {{MyURL}}/items
####
Response:
```json
[
  {
    "id": 1,
    "name": "Hammer",
    "price": 25.5,
    "category": "TOOL"
  },
  {
    "id": 2,
    "name": "Screwdriver",
    "price": 10.0,
    "category": "TOOL"
  },
  {
    "id": 3,
    "name": "Wrench",
    "price": 15.75,
    "category": "TOOL"
  },
  {
    "id": 4,
    "name": "Pliers",
    "price": 12.25,
    "category": "TOOL"
  },
  {
    "id": 5,
    "name": "Notebook",
    "price": 5.0,
    "category": "VIDEO"
  },
  {
    "id": 6,
    "name": "Exorcist",
    "price": 1.5,
    "category": "VIDEO"
  },
  {
    "id": 7,
    "name": "Christina Aguilera - Bionic Album",
    "price": 2.5,
    "category": "SOUND"
  },
  {
    "id": 8,
    "name": "Adele - 21 Album",
    "price": 3.5,
    "category": "SOUND"
  },
  {
    "id": 9,
    "name": "Oculus Rift VR",
    "price": 399.99,
    "category": "VR"
  },
  {
    "id": 10,
    "name": "HP Printer",
    "price": 120.0,
    "category": "PRINT"
  },
  {
    "id": 11,
    "name": "Canon Printer",
    "price": 150.0,
    "category": "PRINT"
  },
  {
    "id": 12,
    "name": "Laser Pointer",
    "price": 8.0,
    "category": "TOOL"
  },
  {
    "id": 13,
    "name": "Blender",
    "price": 60.0,
    "category": "VIDEO"
  },
  {
    "id": 14,
    "name": "Yoga Mat",
    "price": 20.0,
    "category": "VR"
  },
  {
    "id": 15,
    "name": "Fitness Tracker",
    "price": 50.0,
    "category": "VR"
  },
  {
    "id": 16,
    "name": "Fitness Tracker",
    "price": 50.0,
    "category": "VR"
  },
  {
    "id": 17,
    "name": "ChainSaw",
    "price": 500.0,
    "category": "TOOL"
  }
]
```

## Fetch item by ID
GET {{MyURL}}/items/1
####
Response:
```json
{
  "id": 1,
  "name": "Hammer",
  "price": 25.5,
  "category": "TOOL"
}
```

## Fetch items by category
GET {{MyURL}}/items/category/TOOL
####
Response:
```json
[
  {
    "id": 1,
    "name": "Hammer",
    "price": 25.5,
    "category": "TOOL"
  },
  {
    "id": 2,
    "name": "Screwdriver",
    "price": 10.0,
    "category": "TOOL"
  },
  {
    "id": 3,
    "name": "Wrench",
    "price": 15.75,
    "category": "TOOL"
  },
  {
    "id": 4,
    "name": "Pliers",
    "price": 12.25,
    "category": "TOOL"
  },
  {
    "id": 12,
    "name": "Laser Pointer",
    "price": 8.0,
    "category": "TOOL"
  },
  {
    "id": 17,
    "name": "ChainSaw",
    "price": 500.0,
    "category": "TOOL"
  }
]
```