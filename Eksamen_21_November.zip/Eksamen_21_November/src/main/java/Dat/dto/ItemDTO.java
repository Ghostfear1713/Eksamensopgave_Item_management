package Dat.dto;


import Dat.Category;

public record ItemDTO(int id, String name, double price, Category category) {
}
