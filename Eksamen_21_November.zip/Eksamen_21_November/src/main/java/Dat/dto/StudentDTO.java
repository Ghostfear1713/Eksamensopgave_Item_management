package Dat.dto;

public record StudentDTO(int id, String name, String email) {
}
