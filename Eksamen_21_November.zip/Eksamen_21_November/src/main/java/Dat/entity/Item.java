package Dat.entity;

import Dat.Category;
import Dat.dto.ItemDTO;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;


@Entity
@Getter
@Setter
@NoArgsConstructor

public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;
    private double purchasePrice;

    @Enumerated(EnumType.STRING)
    private Category category;

    private LocalDate acquisitionDate;
    private String description;

    @ManyToOne
    @JoinColumn(name = "student_id")
    private Student student;


    public Item(String name, double purchasePrice, Category category, LocalDate acquisitionDate, String description) {
        this.name = name;
        this.purchasePrice = purchasePrice;
        this.category = category;
        this.acquisitionDate = acquisitionDate;
        this.description = description;
    }

    public ItemDTO toDTO() {
        return new ItemDTO(id, name, purchasePrice, category);
    }

}
