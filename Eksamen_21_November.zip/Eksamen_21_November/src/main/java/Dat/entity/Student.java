package Dat.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String name;
    private String email;
    private LocalDate enrollmentDate;
    private int phoneNumber;

    @OneToMany(mappedBy = "student")
    private Set<Item> itemList = new HashSet<>();

    public Student(String name, String email, LocalDate enrollmentDate, int phoneNumber) {
        this.name = name;
        this.email = email;
        this.enrollmentDate = enrollmentDate;
        this.phoneNumber = phoneNumber;
    }

    public void borrowItem(Item item) {
        item.setStudent(this);
        itemList.add(item);
    }
    public void returnItem(Item item) {
        item.setStudent(null);
        itemList.remove(item);
    }



}
